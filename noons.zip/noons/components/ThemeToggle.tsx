
import React from 'react';

interface ThemeToggleProps {
  isDarkMode: boolean;
  onToggle: () => void;
}

const ThemeToggle: React.FC<ThemeToggleProps> = ({ isDarkMode, onToggle }) => {
  return (
    <div className="flex items-center space-x-3">
      {/* Sun Icon */}
      <svg 
        xmlns="http://www.w3.org/2000/svg" 
        className={`w-5 h-5 ${!isDarkMode ? 'text-green-500' : 'text-gray-500'}`} 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      >
        <circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/>
      </svg>

      {/* Toggle Button */}
      <button 
        onClick={onToggle}
        className={`relative w-12 h-6 rounded-full transition-colors duration-200 ${isDarkMode ? 'bg-[#22C55E]' : 'bg-gray-300'}`}
      >
        <div 
          className={`absolute top-1 left-1 bg-black w-4 h-4 rounded-md transition-transform duration-200 ${isDarkMode ? 'translate-x-6' : 'translate-x-0'}`}
        />
      </button>

      {/* Moon Icon */}
      <svg 
        xmlns="http://www.w3.org/2000/svg" 
        className={`w-5 h-5 ${isDarkMode ? 'text-green-500' : 'text-gray-500'}`} 
        viewBox="0 0 24 24" 
        fill="none" 
        stroke="currentColor" 
        strokeWidth="2" 
        strokeLinecap="round" 
        strokeLinejoin="round"
      >
        <path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/>
      </svg>
    </div>
  );
};

export default ThemeToggle;
